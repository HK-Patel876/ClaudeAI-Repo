"""AI Trading System Backend"""
__version__ = "1.0.0"
